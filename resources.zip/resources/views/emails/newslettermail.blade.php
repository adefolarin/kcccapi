<!DOCTYPE html>
<html>
<head>
    <title>KCCC</title>
</head>
<body>
    <h4>News Letter Subscription</h4>
    <p>Subscriber's Email: {{ $mailData['newsletter_email'] }}</p>
    
    <p>The above email has successfully subscribed to the news letter</p>
     
</body>
</html>