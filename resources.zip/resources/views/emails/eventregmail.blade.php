<!DOCTYPE html>
<html>
<head>
    <title>KCCC</title>
</head>
<body>
    <h3>{{ $mailData['eventname'] }}</h3>
    <h4>{{ $mailData['title'] }}</h4>
    <p>{{ $mailData['body'] }}</p>
       
    <p>Thank you</p>
</body>
</html>